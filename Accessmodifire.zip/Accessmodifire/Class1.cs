﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Accessmodifire
{
    class Class1
    {
        public string name
        { 
            get;
            set;
        }
        public int roll
        {
            get;
            set;
        }
        public string address
        {
            get;
            set;
        }
    }
}
