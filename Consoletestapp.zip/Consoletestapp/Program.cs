﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Consoletestapp
{
    class Program
    {
        private int prodID;
        public int ProductId 
        { 
            get { return prodID; } 
            set { prodID = value; }
                }
        public string ProductName { get; set; }
        private int Qty;
        public int Quantity
        {
            get
            {
                return Qty;
            }
        }
        public int Purchase
        {
            set 
            { 
                Qty = Qty + value; 
            }
        }
        public int Sales
        {
            set
            {
                if (value < Qty)
                {

                    Qty -= value;
                }
                else
                    Console.WriteLine("nate able sell product bacuase of less quaty");
            }
        }

        public override string ToString()
        {
            return "Product : ID = " + prodID.ToString();
              +"Name = " + ProductName "qty = " +Qty.ToString();
        }
    }
}
