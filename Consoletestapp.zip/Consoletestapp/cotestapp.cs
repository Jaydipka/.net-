﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Consoletestapp
{
    class cotestapp
    {
        static void main1(string[] args)

        static void main(string[] args)
        {
            Product p = new Product();
            p.ProductId = 1;
            p.ProductName = "computer";
            Console.WriteLine(p.Tostring());
            p.Pur
        }
    }
}
